var searchData=
[
  ['gnu_20free_20documentation_20license_0',['GNU Free Documentation License',['../gnu-fdl.html',1,'']]],
  ['gnu_20general_20public_20license_1',['GNU General Public License',['../gnu-gpl.html',1,'']]]
];
