var searchData=
[
  ['result_0',['Result',['../main_8cpp.html#a28287671eaf7406afd604bd055ba4066',1,'main.cpp']]]
];
